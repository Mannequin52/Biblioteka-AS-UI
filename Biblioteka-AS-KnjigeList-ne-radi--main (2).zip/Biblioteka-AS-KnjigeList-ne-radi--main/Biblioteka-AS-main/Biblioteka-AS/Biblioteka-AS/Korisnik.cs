﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Biblioteka_AS
{
    public partial class Korisnik : Form
    {
        List <KorisnikClass> korisnikList = new List<KorisnikClass>();
        public Korisnik()
        {
            InitializeComponent();
        }

        private void imekorisniktxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                KorisnikClass upiskorisnik = new KorisnikClass(imekorisniktxt.Text, prezimekorisniktxt.Text, Convert.ToString(dobkorisniktxt.Text), brojteltxt.Text, emailtxt.Text, oibkorisniktxt.Text, adresakorisniktxt.Text);
                korisnikList.Add(upiskorisnik);


            }
            catch (Exception greska)
            {
                MessageBox.Show(greska.Message, "Pogrešan unos.",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            public class Tester
        {
            private static XDocument CreateCustomerListXml()
            {
                List<KorisnikClass> korisnikList = CreateUserList();

                var dokumentXmlKorisnici = new XDocument(new XElement("lista_klijenata",
                    from KorisnikClass in korisnikList
                    select new XElement("Korisnik",
                        new XAttribute("Ime", KorisnikClass.Ime),
                        new XAttribute("Prezime", KorisnikClass.Prezime),
                        new XElement("EmailAdresa", KorisnikClass.Email),
                        new XAttribute("God", KorisnikClass.God),
                        new XAttribute("BrojTel", KorisnikClass.Brtel),
                        new XAttribute("OIB", KorisnikClass.Oib),
                        new XAttribute("Adresa", KorisnikClass.Adresa)
                        )));
                return dokumentXmlKorisnici;
            }

            private static List<KorisnikClass> CreateUserList()
            {
                List<KorisnikClass> korisnikLista = new List<KorisnikClass> { 
                
                };
                return korisnikLista;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
